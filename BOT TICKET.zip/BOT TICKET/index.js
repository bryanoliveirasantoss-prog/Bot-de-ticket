const {
  Client,
  GatewayIntentBits,
  ChannelType,
  PermissionsBitField,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  StringSelectMenuBuilder,
  SlashCommandBuilder,
  REST,
  Routes
} = require("discord.js");

const fs = require("fs");

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

const TOKEN = process.env.TOKEN;

if (!TOKEN) {
  console.log("TOKEN não configurado.");
  process.exit(1);
}

const configPath = "./config.json";

let config = {
  staffRole: null,
  category: null,
  logChannel: null
};

if (fs.existsSync(configPath)) {
  try {
    config = JSON.parse(fs.readFileSync(configPath, "utf8"));
  } catch {}
}

function saveConfig() {
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
}

const tipos = {
  suporte: "🛠️ Suporte",
  reembolso: "💰 Reembolso",
  evento: "🎉 Recebe Evento",
  mediador: "🛡️ Vagas Mediador",
  divulgacao: "📢 Divulgação"
};

function painelTickets() {
  const embed = new EmbedBuilder()
    .setTitle("🎫 Central de Atendimento")
    .setDescription(
      "Selecione abaixo o motivo do seu atendimento.\n\n" +
      "🛠️ **Suporte**\n" +
      "💰 **Reembolso**\n" +
      "🎉 **Recebe Evento**\n" +
      "🛡️ **Vagas Mediador**\n" +
      "📢 **Divulgação**\n\n" +
      "⚠️ Você só pode ter **1 ticket aberto por vez**."
    );

  const menu = new StringSelectMenuBuilder()
    .setCustomId("abrir_ticket")
    .setPlaceholder("Selecione uma opção")
    .addOptions(
      {
        label: "Suporte",
        value: "suporte",
        emoji: "🛠️"
      },
      {
        label: "Reembolso",
        value: "reembolso",
        emoji: "💰"
      },
      {
        label: "Recebe Evento",
        value: "evento",
        emoji: "🎉"
      },
      {
        label: "Vagas Mediador",
        value: "mediador",
        emoji: "🛡️"
      },
      {
        label: "Divulgação",
        value: "divulgacao",
        emoji: "📢"
      }
    );

  return {
    embeds: [embed],
    components: [
      new ActionRowBuilder().addComponents(menu)
    ]
  };
}

client.once("ready", async () => {
  console.log(`✅ Bot online: ${client.user.tag}`);

  const comandos = [
    new SlashCommandBuilder()
      .setName("ticket")
      .setDescription("Envia o painel de tickets"),

    new SlashCommandBuilder()
      .setName("configurar")
      .setDescription("Configura o sistema de tickets")
  ];

  const rest = new REST({ version: "10" }).setToken(TOKEN);

  for (const guild of client.guilds.cache.values()) {
    await rest.put(
      Routes.applicationGuildCommands(client.user.id, guild.id),
      {
        body: comandos.map(c => c.toJSON())
      }
    );
  }

  console.log("✅ Comandos registrados.");
});

client.on("interactionCreate", async interaction => {

  if (interaction.isChatInputCommand()) {

    if (interaction.commandName === "ticket") {

      if (!interaction.member.permissions.has(
        PermissionsBitField.Flags.Administrator
      )) {
        return interaction.reply({
          content: "❌ Você precisa ser administrador.",
          ephemeral: true
        });
      }

      await interaction.channel.send(painelTickets());

      return interaction.reply({
        content: "✅ Painel enviado!",
        ephemeral: true
      });
    }

    if (interaction.commandName === "configurar") {

      if (!interaction.member.permissions.has(
        PermissionsBitField.Flags.Administrator
      )) {
        return interaction.reply({
          content: "❌ Você precisa ser administrador.",
          ephemeral: true
        });
      }

      const embed = new EmbedBuilder()
        .setTitle("⚙️ Configuração do Ticket")
        .setDescription(
          "Use os comandos abaixo para configurar o sistema:\n\n" +
          "`/configurar` — abre este painel.\n\n" +
          "A configuração avançada poderá definir:\n" +
          "👮 Cargo da equipe\n" +
          "📂 Categoria dos tickets\n" +
          "📋 Canal de logs"
        );

      return interaction.reply({
        embeds: [embed],
        ephemeral: true
      });
    }
  }

  if (interaction.isStringSelectMenu()) {

    if (interaction.customId !== "abrir_ticket") return;

    const tipo = interaction.values[0];

    const canais = interaction.guild.channels.cache.filter(
      channel =>
        channel.type === ChannelType.GuildText &&
        channel.topic &&
        channel.topic.includes(`TICKET_USER:${interaction.user.id}`)
    );

    if (canais.size > 0) {
      return interaction.reply({
        content: `❌ Você já possui um ticket aberto: ${canais.first()}`,
        ephemeral: true
      });
    }

    const nome = `${tipo}-${interaction.user.username}`
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, "");

    const overwrites = [
      {
        id: interaction.guild.id,
        deny: [PermissionsBitField.Flags.ViewChannel]
      },
      {
        id: interaction.user.id,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory
        ]
      }
    ];

    if (config.staffRole) {
      overwrites.push({
        id: config.staffRole,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory
        ]
      });
    }

    const canal = await interaction.guild.channels.create({
      name: nome,
      type: ChannelType.GuildText,
      parent: config.category || undefined,
      topic: `TICKET_USER:${interaction.user.id}`,
      permissionOverwrites: overwrites
    });

    const embed = new EmbedBuilder()
      .setTitle(`${tipos[tipo]}`)
      .setDescription(
        `Olá ${interaction.user}! 👋\n\n` +
        `Seu ticket de **${tipos[tipo]}** foi criado.\n` +
        `Aguarde a equipe responder.\n\n` +
        `🔒 Use o botão abaixo para fechar o ticket.`
      );

    const fechar = new ButtonBuilder()
      .setCustomId("fechar_ticket")
      .setLabel("Fechar Ticket")
      .setEmoji("🔒")
      .setStyle(ButtonStyle.Danger);

    await canal.send({
      content: `<@${interaction.user.id}>`,
      embeds: [embed],
      components: [
        new ActionRowBuilder().addComponents(fechar)
      ]
    });

    return interaction.reply({
      content: `✅ Seu ticket foi criado: ${canal}`,
      ephemeral: true
    });
  }

  if (interaction.isButton()) {

    if (interaction.customId === "fechar_ticket") {

      await interaction.reply("🔒 Este ticket será fechado em 5 segundos.");

      setTimeout(async () => {
        await interaction.channel.delete().catch(() => {});
      }, 5000);
    }
  }
});

client.login(TOKEN);